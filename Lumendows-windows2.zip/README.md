# Lumendows

⚡ A Windows-only fork of **LumenOS**.

## Overview

Lumendows is designed to run **exclusively on Microsoft Windows (10/11 and Server)**.  
It is a feature-equivalent adaptation of LumenOS, but stripped of Linux/macOS compatibility.

## Requirements

- Windows 10/11 or Windows Server (x64)
- PowerShell 5.1+ or PowerShell Core (pwsh)
- [Node.js LTS](https://nodejs.org/) (install via `winget` or `choco`)
- Git (optional, for development)

## Installation

### Using Winget (recommended)
```powershell
winget install OpenJS.NodeJS.LTS
winget install Git.Git
```

### Using Chocolatey
```powershell
choco install nodejs-lts git
```

Clone the repo and install dependencies:
```powershell
git clone https://github.com/YOUR-USERNAME/Lumendows.git
cd Lumendows
npm install
```

## Usage

Start the application:
```powershell
.\scripts\ensure-windows.ps1
npm start
```

Or directly with:
```powershell
npm run start
```

## Development

- All scripts are provided as **PowerShell (`.ps1`)** equivalents of the original bash scripts.
- GitHub Actions workflow runs **Windows-only builds/tests**.

## Notes

- This project will **exit immediately** if run on Linux or macOS.
- Original cross-platform support from LumenOS has been intentionally removed.

---

© 2025 Lumendows Project. Forked from LumenOS.
