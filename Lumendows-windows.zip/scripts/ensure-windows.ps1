# Windows-only check script for Lumendows
if (-not $IsWindows) {
    Write-Error "This project only supports Windows."
    exit 1
}
